import fishman

flag = input("input your flag here:")
fishman.init()
print(fishman.check(flag))
