[这个题目的流程]
装上属于你的小摩托（fishman.cp39-win_amd64.pyd）,
骑着它（run main.py）永远不会堵车（you win）。
