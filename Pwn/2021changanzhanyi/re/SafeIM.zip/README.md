#### client 文件夹

- SafeIM.exe：即时通讯软件客户端，直接双击运行
- 其他 dll：依赖库，请勿改变他们之间的相对位置



#### server 文件夹

- SafeIM_Server.exe：即时通讯软件服务端，需要一个命令行参数来指定监听在哪个端口上
- libssl-1_1.dll、libcrypto-1_1.dll：依赖库，请勿改变他们之间的相对位置
- certs 文件夹：存放服务端相关证书，请勿改变他们之间的相对位置



#### capture.pcap

某用户在使用 SafeIM 应用过程中捕获到的重要流量



#### 运行说明

首先在命令行运行 **server 目录**下的服务端程序 **SafeIM_Server.exe**，并指定一个端口，效果如下：

```powershell
D:\server>SafeIM_Server.exe 23333
[+] Server is working at 23333
```

**注意保证当前工作路径为 SafeIM_Server.exe 所在目录，否则会出现报错**

然后运行 **client 目录**下的客户端桌面应用 **SafeIM.exe**，在 **Nick Name** 一栏填写登录所用的用户名，在 **IP:PORT** 一栏填写服务端信息（注意保持冒号分隔的形式），点击 Login 即可登录软件

可以将 client 文件夹拷贝至其他目录，再运行其中的 **SafeIM.exe**，模拟多用户登录



PS. 祝玩得开心~